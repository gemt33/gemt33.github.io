#include <stdio.h>
#include <stdbool.h>

int primesUnder20[] = {2, 3, 5, 7, 11, 13, 17, 19};

int main() {
    int diviser;
    int i;
    int product = 1;

    for (i=0; i<8; i++) {
        product *= primesUnder20[i];
    }

    product *= 24;

    printf("%d\n", product);

    printf("\n------------------\nCHECK:\n------------------\n");
    for (i=1; i<21; i++) {
        printf("%d%c%d=%d\t%s\n", product, 37, i, product%i, (product%i == 0)? "OK": "NOT CORRECT");
    }

}