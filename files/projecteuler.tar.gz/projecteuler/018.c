#include <stdio.h>
#define RED "\x1b[31m"
#define RESET "\x1b[0m"


// convert an int to a string of its binary representation
int intToBin(int n, char s[]) {
    int i;

    for (i=14; i>=0; i--) {
        s[i] = (char) ((1 & n) + 48);
        n >>= 1;
    }
    return 0;
}

// display the pyramid with the path in red
int displayPath(int pathId, int pyramid[15][15]) {
    int row, column, i;
    int columnRed = 0;

    for (row=0; row<15; row++) {
        for (i=0; i<15-row-1; i++) printf("  ");
        if (row != 0) {
            columnRed += (1&pathId);
            pathId >>= 1;
        }
            for (column=0; column<=row; column++) {
                if (pyramid[row][column] < 10) {
                    if (row == 0 || columnRed == column) {
                        printf(RED"0%d  "RESET, pyramid[row][column]);
                    } else {
                        printf("0%d  ", pyramid[row][column]);
                    }
                } else {
                    if (row == 0 || columnRed == column) {
                        printf(RED"%d  "RESET, pyramid[row][column]);
                    } else {
                        printf("%d  ", pyramid[row][column]);
                    }
                }
            }
        printf("\n");
    }
}


int main() {
    int pyramidSize = 15; // number of pyramid rows
    int pyramid[pyramidSize][pyramidSize]; // will contain the numbers of the pyramid
    int row, column;
    int maxIdPath = 1 << (pyramidSize-1); // the max idPath : 2**(pyramidSize-1)
    int idPath; // idPath is a pyramidSize-1 bit size integer. Each bit tells the direction for the row below (left or right)
    int tempPath; // used to not modiy idPath during path calculation
    int sum, maxSum = 0; // used to sum the numbers of the path
    int maxSumPath;
    int i;
    char binaryPath[15]; // binary representation of a path


    // read the pyramid data from the file and put it in pyramid 2D array
    FILE * data = fopen("./018file", "r");
    for (row=0; row<pyramidSize; row++) {
        //for (i=0; i<pyramidSize-row-1; i++) printf("  ");
        for (column=0; column<=row; column++) {
            fscanf(data, "%d ", &pyramid[row][column]);
            if (pyramid[row][column] < 10) printf("0");
            //printf("%d  ", pyramid[row][column]);
        }
        //printf("\n");
    }
    fclose(data);


    // calculate the sum for each path and pick the max one
    for (idPath=0; idPath<maxIdPath; idPath++) {
        tempPath = idPath;
        column = 0;
        sum = 75; // there is always 75 in the sum (the top of the pyramid)
        for (row=1; row<pyramidSize; row++) { // start at the 2nd row
            column += (1 & tempPath); // we mask all except the LSB
            tempPath >>= 1; // tempPath is right shifted
            sum += pyramid[row][column];
        }
        if (sum>maxSum) {
            maxSum = sum;
            maxSumPath = idPath;
        }
    }

    // display the result
    intToBin(maxSumPath, binaryPath);
    printf("\nmax: %d,\tpath: %s\n", maxSum, binaryPath);
    displayPath(maxSumPath, pyramid);


    return 0;
}