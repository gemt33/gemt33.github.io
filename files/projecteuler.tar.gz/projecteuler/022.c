#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int alphabeticalValue(char * word) {
    int i = 0;
    int sum = 0;

    while (word[i] != '\0') {
        sum += (int) word[i] - 64;
        i++;
    }
    return sum;
}

int cmpstr(const void * void1, const void * void2) { // need to cast to call strcmp with qsort
    char * str1 = (char *) void1;
    char * str2 = (char *) void2;
    return strcmp(str1, str2);
}

int main() {
    char names[6000][40]; // an array to store 6k names of max length 19
    FILE * data = fopen("./022names.txt", "r");
    int indexName = 0;
    int indexChar = 0;
    int nbNames;
    char c;
    long sum = 0;

    while ((c = fgetc(data)) != EOF) {
        if (c == ',') { // coma indicates that there is a new value
            indexName++;
            indexChar = 0; // reset the char index
        }
        else if (c != '"') { // ignore '"'
            names[indexName][indexChar] = c;
            indexChar++;
        }
    }

    fclose(data);

    nbNames = indexName+1;

    qsort(names, nbNames, 40*sizeof(char), cmpstr);

    for (indexName=0; indexName<nbNames; indexName++) {
        //printf("%s, %d, %d\n", names[indexName], alphabeticalValue(names[indexName]), (indexName+1));
        sum += alphabeticalValue(names[indexName])*(indexName+1);
    }

    printf("%ld\n", sum);

    return 0;
}