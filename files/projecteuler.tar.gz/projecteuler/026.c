#include <stdio.h>

int remainders[1000]; // a memory of the remainders to find a loop

int remaindersContains(int n, int indexMax) { // searches for n in the array and returns its index if found
    int i;

    for (i=0; i<indexMax; i++) {
        if (remainders[i] == n) {
            return i;
        }
    }
    return -1;
}

int main() {
    int d;
    int remainder;
    int i,j;
    int index;
    int sizeLoop; // size of the digit loop
    int maxSizeLoop = 0;
    int dMax; // d with the biggest loop

    for (d=1; d<1001; d++) {
        remainder = 1; // remainder of the euclidean division
        index = 0;
        sizeLoop = 0;
        for (j=0; j<1000; j++) { // print the first 100 digits
            i = remainder/d; // i is the jth digit after the coma
            remainder -= d*i;
            remainders[index] = remainder;
            if (remainder == 0) break; // if nothing remains break
            if (remaindersContains(remainder, index) >= 0) { // if this remainder is already stored in the list
                sizeLoop = index - remaindersContains(remainder, index); // length of the loop
                if (sizeLoop > maxSizeLoop) {
                    maxSizeLoop = sizeLoop;
                    dMax = d;
                }
                break;
            }
            index++;
            remainder *= 10; // multiply by 10 for the next division
        }
    }
    printf("%d, %d\n", dMax, maxSizeLoop);
    return 0;
}