#include <stdio.h>
#include <stdlib.h>


int main() {
    FILE *data;
    char arrayString[51];
    long long total = 0;
    char totalString[15];
    int i;

    if ((data = fopen("./013file", "r")) == NULL) {
        printf("cannot open file.\n");
        exit(1);
    }

    for (i=0; i<100; i++) {
        fscanf(data, "%s\n", &arrayString[0]);
        arrayString[12] = '\0';
        total += atoll(&arrayString[0]);
    }

    sprintf(totalString, "%lld\n", total);
    totalString[10] = '\0';
    printf("%s\n", totalString);

    return 0;
}