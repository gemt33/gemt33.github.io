#include <stdio.h>
#include <gmp.h>

int main() {
    mpz_t fib1;
    mpz_t fib2;
    int i = -1;
    int index = 3;

    mpz_inits(fib1, fib2, NULL);

    mpz_set_ui(fib1, 1);
    mpz_set_ui(fib2, 1);

    while (mpz_sizeinbase(fib1, 10) < 1000) {
        if (i == 1) {
            mpz_add(fib1, fib1, fib2);
            //mpz_out_str(stdout, 10, fib1);
        } else {
            mpz_add(fib2, fib2, fib1);
            //mpz_out_str(stdout, 10, fib2);
        }
        i = -1*i;
        index++;
        //printf("\n");
    }


    printf("%d\n", index);
    mpz_clears(fib1, fib2, NULL);
    return 0;
}