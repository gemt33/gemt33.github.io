#include <stdio.h>
#include <stdbool.h>
#include <math.h>

int first1kPrimes[1000];                // this array will hold the first 1000th primes

bool isPrime(unsigned long long n) {    // returns true if n is prime else false
    if (n == 1) return false;           // 1 is not prime
    bool isPrime = true;                // until we cannot find a diviser, we consider that n is prime
    unsigned long long i;

    for (i=2; i<(unsigned long long)sqrt((double)n); i++) {    // we test if each prime below sqrt(n) is a divisor
        if (n%i == 0){
            isPrime = false;
            return isPrime;
        }
    }
    return isPrime;
}

bool isPrimeFaster(unsigned long long n) {    // returns true if n is prime else false
    if (n == 1) return false;           // 1 is not prime
    bool isPrime = true;                // until we cannot find a diviser, we consider that n is prime
    int i;

    for (i=0; first1kPrimes[i]<=(int)sqrt((double)n); i++) {    // we test if each prime below sqrt(n) is a divisor
        if (n%first1kPrimes[i] == 0){
            isPrime = false;
            return isPrime;
        }
    }
    return isPrime;
}


int main() {
    unsigned long long i = 1;
    int index = 0;
    int primeIndex = 0;
    int lastPrime;

    // filling the first1kPrimes array
    while (index < 1000) {
        if (isPrime(i) == true) {
            first1kPrimes[index] = (int) i;
            index++;
        }
        i++;
    }
    printf("1000th prime: %d\n", first1kPrimes[999]);

    i = 1;

    while (primeIndex <= 10000) {
        if (isPrimeFaster(i) == true) {
            lastPrime = i;
            primeIndex++;
        }
        i++;
    }
    printf("%dth, %llu\n", primeIndex, i-1);

    return 0;
}