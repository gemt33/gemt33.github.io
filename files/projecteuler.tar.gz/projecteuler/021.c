#include <stdio.h>


int sumDivisorsOf(int n) { // retruns the sum of all the divisors of n (n not included)
    int i;
    int sum = 0;

    for (i=1; i<=n/2; i++) {
        if (n%i == 0) {
            sum += i;
        }
    }

    return sum;
}

int main() {
    int number;
    int sum = 0;
    int sumForNumber;

    for (number=1; number<10000; number++) {
        sumForNumber = sumDivisorsOf(number);
        if ((sumForNumber > number) && (number == sumDivisorsOf(sumForNumber))) { // do not count twice a pair
            sum += number + sumForNumber;
        }
    }

    printf("%d\n", sum);

    return 0;
}