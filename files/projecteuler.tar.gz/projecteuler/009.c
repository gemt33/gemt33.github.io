#include <stdio.h>
#include <stdbool.h>

int square(int n) {
    return n*n;
}

bool checkTriplet(int a, int b, int c) { // check if a^2 + b^2 = c^2
    bool res = (square(a)+square(b) == square(c));
    if (res == true) {
        printf("triplet found: a = %d, b = %d, c= %d\n", a, b, c);
        printf("a^2 + b^2 = %d, c^2 = %d\n", square(a) + square(b), square(c));
        printf("a + b + c = %d\n", a+b+c);
        printf("a * b * c = %d\n", a*b*c);
    }
    return res;
}


int main() { // we brute force all the possibilities such that a < b < c and a + b + c = 1000
    int a, b, c;
    a = 1;
    unsigned long long iterations = 0;

    while (a<333) { // 332 is the maximum we can have for a
        b = a + 1; // b >= a + 1
        while (b<=(499-a/2)) { // you have to write down on paper the sequence to see this
            c = 1000 - (a+b);
            iterations++;
            if (checkTriplet(a, b, c) == true) {
                printf("executed in %llu iterations.\n", iterations);
                return 0;
            }
            b++;
        }
        a++;
    }

    return 0;
}