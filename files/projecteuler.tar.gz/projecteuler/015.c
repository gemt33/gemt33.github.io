/*
Starting in the top left corner of a 2×2 grid, and only being able to move to the right and down, there are exactly 6 routes to the bottom right corner.
How many such routes are there through a 20×20 grid?

No need to code for this problem:

let's define a point on the grid with (x, y) coordinates. The upper left corner is (0, 0), x is the horizontal axis and y the vertical one.
0 <= x < 20, 0 <= y < 20. x + y = number of steps. There are 40 steps in total.

The number of paths to reach the bottom right corner is the number of path to reach either the right side or the bottom side.
This is because you can only move right or down. When x or y hits 20, there are no more path possibilities for this point.

Starting at (0, 0), we have 2 possibilities: (0, 0)->(0, 1) or (0, 0)->(1, 0).
and then again 2 possibilities for these 2 coordinates. We can proceed by the same logic until we reach the right or bottom side: 20 steps.

We can then reason by symetry (with the axis (0, 0), (19, 19) ) for the following steps.
We will just consider the right side.

If we are in (20, 0) there is just one path possible.
If we are in (19, 1) there are 20 paths possible.
If we are in (18, 2) there are 19^2 paths possible.
If we are in (a, 20-a) there are (a+1)^()

*/

#include <stdio.h>
#include <stdlib.h>

long square(long n) {
    return n*n;
}

long fact(int n) {
    if (n<= 1) return 1;
    return n*fact(n-1);
}

long combination(int all, int among) {
    if (among == 0 || among == all) return 1;
    if (among == 1 || among == all-1) return all;
    return (fact(all)/(fact(among)*fact(all-among)));
}

int pascalTriangle(int n) {
    int i, j, k;
    for (i=0; i<=n; i++) {
        for (k=0; k<(n-i); k++) printf("\t");
        for (j=0; j<=i; j++) {
            printf("%ld\t\t", combination(i, j));
        }
        printf("\n");
    }
}

long nbLatticePaths(int n) {
    int i;
    long res = 0;

    for (i=0; i<=n; i++) {
        res += square(combination(n, i));
    }
    return res;
}

int main(int argc, char **argv) {

    if (argc == 2) {

        printf("%ld\n", nbLatticePaths(atoi(argv[1])));
    } else {
        printf("%ld\n", nbLatticePaths(20));
    }

    return 0;
}