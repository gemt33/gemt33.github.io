#include <stdio.h>
#include <stdbool.h>
#include <math.h>

// The sum of the primes below 10 is 2 + 3 + 5 + 7 = 17.
// Find the sum of all the primes below two million.

// the 224th prime is 1423,
// to check if a number is prime, you need to check if
// non of the primes below its square root divides it.
// 1423^2 = 2.024.929
// let's create an array of the first 224 primes.
#define NB_PRIMES 224


int primes[NB_PRIMES];

bool isPrime(int n) {
    int i;
    bool isPrime = true;

    if (n == 1) return false;

    for (i=2; i<=sqrt(n); i++) {
        if (n%i == 0) {
            isPrime = false;
            return isPrime;
        }
    }
    return isPrime;
}

bool isPrimeFaster(unsigned long long n) {
    int i;

    if (n == 1) return false;

    for (i=0; primes[i]<=sqrt(n); i++) {
        if (n%primes[i] == 0) {
            return false;
        }
    }
    return true;
}


int initPrimes() {
    int index = 0;
    int i = 1;

    while (index<NB_PRIMES) {
        if (isPrime(i) == true) {
            primes[index] = i;
            index++;
        }
        i++;
    }
    return 0;
}

int main() {
    unsigned long long sum = 0;
    unsigned long long number = 1;

    initPrimes();

    while (number<2000000) {
        if (isPrimeFaster(number) == true) {
            sum += (unsigned long long) number;
        }
        number++;
    }
    printf("the sum of all primes below 2.000.000 is: %llu\n", sum);



    return 0;
}