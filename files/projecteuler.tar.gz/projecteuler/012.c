#include <stdio.h>
#include "./lib/primes.h"


int timesItDivides(int n, int i) { // returns how many times i divides n
    int number = n;
    int times = 0;
    while (number%i == 0) {
        number /= i;
        times++;
    }
    return times;
}

int divisors(int n, int *primes, int number) { // returns the number of divisors n has
    int i = 0;
    int nbDivisors = 1;
    int times;

    while (primes[i] < sqrt(n) && i < number) { // for each prime before sqrt(n)
        times = timesItDivides(n, primes[i]);   // we check how many times it divides n
        if (times != 0) {
            nbDivisors *= times + 1; // if n = a^x + b^y + c^z... with a, b and c primes,
                                     // then n has (x + 1)(y + 1)(z + 1)... divisors
        }
        i++;
    }
    return nbDivisors;
}


int main() {
    int nbOfDivisors;
    int maxDivisors = 0;
    int number = 1000;
    int primes[number]; // array of the first 1000 primes
    int triangle = 0;
    int i = 1;

    initPrimes(primes, number); // this function is in the primes.h library,
                                //  it initializes the primes array

    while (maxDivisors < 500) {
        triangle += i; // generates the triangle suite
        i++;
        nbOfDivisors = divisors(triangle, primes, number);
        if (nbOfDivisors > maxDivisors) {
            maxDivisors = nbOfDivisors;
        }
    }

    printf("%d, %d\n", triangle, maxDivisors);

    return 0;
}