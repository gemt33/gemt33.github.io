#include <stdio.h>

// Just to train with enum types
typedef enum {Mon, Tue, Wed, Thu, Fri, Sat, Sun} day;
typedef enum {Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec} month;

// number of day in February in function of the year
int nbDaysFebIn(int year) {
    return ((year%4 == 0 && ((year%100 != 0) || (year%400 == 0))) == 1) + 28;
}

// returns the day of the week it will be in days days
day dayNDaysAfter(day currentDay, int days) {
    return (currentDay+days)%7;
}

int main() {
    int year;
    month monthCount;
    int totalSun1stOfMonth = 0;
    day stDayOfYear;
    day stDayOfMonth;

    // 1st day of 1901 is Tuesday
    stDayOfYear = Tue;
    stDayOfMonth = stDayOfYear;
    for (year=1901; year<2001; year++) {
        for (monthCount=0; monthCount<12; monthCount++){
            if (stDayOfMonth == Sun) totalSun1stOfMonth++;
            switch (monthCount) {
                case Jan: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 31); break;
                case Feb: stDayOfMonth = dayNDaysAfter(stDayOfMonth, nbDaysFebIn(year)); break;
                case Mar: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 31); break;
                case Apr: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 30); break;
                case May: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 31); break;
                case Jun: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 30); break;
                case Jul: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 31); break;
                case Aug: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 31); break;
                case Sep: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 30); break;
                case Oct: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 31); break;
                case Nov: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 30); break;
                case Dec: stDayOfMonth = dayNDaysAfter(stDayOfMonth, 31); break;
                default: break;
            }
        }
    }

    // print result
    printf("%d\n", totalSun1stOfMonth);

    return 0;
}