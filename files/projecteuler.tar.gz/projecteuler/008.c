#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#define N_DIGITS 13

char data[] = "7316717653133062491922511967442657474235534919493496983520312774506326239578318016984801869478851843858615607891129494954595017379583319528532088055111254069874715852386305071569329096329522744304355766896648950445244523161731856403098711121722383113622298934233803081353362766142828064444866452387493035890729629049156044077239071381051585930796086670172427121883998797908792274921901699720888093776657273330010533678812202354218097512545405947522435258490771167055601360483958644670632441572215539753697817977846174064955149290862569321978468622482839722413756570560574902614079729686524145351004748216637048440319989000889524345065854122758866688116427171479924442928230863465674813919123162824586178664583591245665294765456828489128831426076900422421902267105562632111110937054421750694165896040807198403850962455444362981230987879927244284909188845801561660979191338754992005240636899125607176060588611646710940507754100225698315520005593572972571636269561882670428252483600823257530420752963450";

int value(char c) {
    return ((int) c) - 48;
}

int testValue() {
    char test[] = "0123456789";
    int i;

    for (i=0; i<10; i++) {
        printf("%c is converted to %d\n", test[i], value(test[i]));
    }
    return 0;
}

int productToStr(int i, char * multiplication) {
    sprintf(multiplication, "%d * %d * %d * %d * %d * %d * %d * %d * %d * %d * %d * %d * %d = ", value(data[i]), value(data[i+1]), value(data[i+2]), value(data[i+3]), value(data[i+4]), value(data[i+5]), value(data[i+6]), value(data[i+7]), value(data[i+8]), value(data[i+9]), value(data[i+10]), value(data[i+11]), value(data[i+12]));
    return 0;
}




int main() {
    unsigned long long maxProduct = 0;
    unsigned long long product;
    int i, j;
    int iOfMax;
    char multiplication[100];

    for (i=0; i<strlen(data) - N_DIGITS; i++) {
        product = 1;
        for (j=i; j<N_DIGITS+i; j++) {
            //printf("j: %d, %d\n", i, N_DIGITS+i);
            product *= (unsigned long long)value(data[j]);
        }
        //printf("%d ", product);
        if (product>maxProduct) {
            maxProduct = product;
            iOfMax = i;

            productToStr(iOfMax, multiplication);
            printf("max by now: %s%llu\n", multiplication, maxProduct);
        }
    }

    printf("max product of %d digits is: %llu\n", N_DIGITS, maxProduct);

    return 0;

}