#include <stdio.h>
#define SIZE 4

int spiral[SIZE][SIZE];

int displayArray(int tab[SIZE][SIZE]) {
    int x, y;
    for (x=0; x<SIZE; x++) {
        for (y=0; y<SIZE; y++) {
            printf("%d\t", tab[x][y]);
        }
        printf("\n");
    }
}

int main() {
    int counter = SIZE * SIZE;
    int i;
    int x, y;
    int minx = 0;
    int maxx = SIZE;
    int miny = 0;
    int maxy = SIZE;
    int direction = 0;

    while (counter > 0) {
        switch (direction) {
            case 0 : goto right; break;
            case 1 : goto down; break;
            case 2 : goto left; break;
            case 3 : goto up; break;
        }

        right:
        for (x=minx; x<maxx; x++) {
            spiral[x][miny] = counter;
            counter--;
        }
        miny++;
        direction++;
        goto end;


        down:
        for (y=miny; y<maxy; y++) {
            spiral[maxx][y] = counter;
            counter--;
        }
        maxx--;
        direction++;
        goto end;


        left:
        for (x=maxx; x>minx; x--) {
            spiral[x][maxy] = counter;
            counter--;
        }
        maxy--;
        direction++;
        goto end;


        up:
        for (y=maxy; y>miny; y--) {
            spiral[minx][y] = counter;
            counter--;
        }
        minx++;
        direction = 0;
        goto end;

        end:;
    }
    displayArray(spiral);
    return 0;
}