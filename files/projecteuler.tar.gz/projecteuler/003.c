#include <stdio.h>
#include <math.h>                       // needed for sqrt()
#include <stdbool.h>                    // needed for the bool type


int first1kPrimes[1000];                // this array will hold the first 1000th primes


// index is used for recursive calls
unsigned long long largestPrimeDiviserOf(unsigned long long n, int index) {
    if (n == 1){                // if largestPrimeDiviser is called with n = 1
        printf("end\n");        // it means we have found all the prime factors of n
        return 0;
    } else if (index == 999) {  // if n is not found in the first1kPrimes array
        printf("end, %llu\n", n);   // no luck, you have to improve this program!
        return 0;
    }
    int primeTester = first1kPrimes[index];
    unsigned long long divBySmallestPrime;

    if (n%primeTester == 0){        // we try to divide n by a the prime primeTester
        divBySmallestPrime = n/(unsigned long long)primeTester;
        printf("%d, %llu\n", primeTester, divBySmallestPrime);
        largestPrimeDiviserOf(divBySmallestPrime, 0);       // if it divides we call
    } else {                                                // largestPrimeDiviser for n/primeTester
        index++;
        largestPrimeDiviserOf(n, index);                    // else we try an other prime
    }

    return 0;
}

bool isPrime(unsigned long long n) {    // returns true if n is prime else false
    if (n == 1) return false;           // 1 is not prime
    bool isPrime = true;                // until we cannot find a diviser, we consider that n is prime
    int i;

    for (i=2; i<(int)sqrt((double)n); i++) {    // we test if each integer below sqrt(n) is a divisor
        if (n%i == 0){
            isPrime = false;
        }
    }
    return isPrime;

}


int main() {

    int i = 1;
    int index = 0;
    unsigned long long number;

    // filling the first1kPrimes array
    while (index < 1000) {
        if (isPrime(i) == true) {
            first1kPrimes[index] = i;
            index++;
        }
        i++;
    }


    printf("Enter a number: ");
    scanf("%llu", &number);

    largestPrimeDiviserOf(number, 0);


    return 0;
}