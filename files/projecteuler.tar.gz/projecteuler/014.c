#include <stdio.h>


long collatz(long n) {
    long i = 0;

    while (n != 1) {
        if (n%2 == 0) {
            n /= 2;
        } else {
            n = 3*n+1;
        }
        i++;
    }
    return i;
}

int main() {
    long maxCollatz = 0;
    long currentCollatz;
    int i;
    int maxI;

    for (i=1; i<1000000; i+=2) { // an even number cannot be the candidate
        currentCollatz = collatz(i);
        if (currentCollatz > maxCollatz) {
            maxCollatz = currentCollatz;
            maxI = i;
        }
    }

    printf("maxI:%d, maxCollatz:%ld\n", maxI, maxCollatz);

}