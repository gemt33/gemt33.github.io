#include <stdio.h>
#include <stdlib.h>

// I stored the 20x20 array in a file 

int fetchArray(char *path, int sizeX, int sizeY, int array[sizeY][sizeX]) {
    FILE *data = fopen(path, "r");
    int i, j;

    if (data == NULL) {
        printf("Cannot open file\n");
        exit(1);
    }
    for (i=0; i<sizeY; i++) {
        for (j=0; j<sizeX; j++) {
            fscanf(data, "%d ", &array[i][j]);
        }
    }

    fclose(data);

}


int main() {
    char *path = "./011file"; // path of the file containing the array
    char *mode = "r"; // open file in read only mode
    int sizeX = 20; // size of array
    int sizeY = 20;
    int array[sizeY][sizeX];
    long long product = 1; // product of n adjacent numbers from the array
    long long maxProduct = 0; // the maximum product
    int sizeProduct = 4; // size of the product
    int i, j, k; // i and j are indexes in the 2D array, k is used to find all the adjacent numbers with i and j fixed
    int maxI, maxJ, searchType; // the indexes of the maxProduct and in which type of product it was found

    fetchArray(path, sizeX, sizeY, array); // fetch the array from the file ./011file

    for (i=0; i<sizeY; i++) { // all horizontal products
        for (j=0; j<sizeX-sizeProduct; j++) {
            for (k=0; k<sizeProduct; k++) {
                product *= (long long) array[i][j+k];
            }
            if (product > maxProduct) {
                maxProduct = product;
                maxI = i;
                maxJ = j;
                searchType = 0;
            }
            product = 1;
        }
    }

    for (i=0; i<sizeY-sizeProduct; i++) { // all vertical products
        for (j=0; j<sizeX; j++) {
            for (k=0; k<sizeProduct; k++) {
                product *= (long long) array[i+k][j];
            }
            if (product > maxProduct) {
                maxProduct = product;
                maxI = i;
                maxJ = j;
                searchType = 1;
            }
            product = 1;
        }
    }

    for (i=0; i<sizeY-sizeProduct; i++) { // all diag1 products
        for (j=0; j<sizeX-sizeProduct; j++) {
            for (k=0; k<sizeProduct; k++) {
                product *= (long long) array[i+k][j+k];
            }
            if (product > maxProduct) {
                maxProduct = product;
                maxI = i;
                maxJ = j;
                searchType = 2;
            }
            product = 1;
        }
    }

    for (i=0; i<sizeY-sizeProduct; i++) { // all diag2 products
        for (j=sizeProduct-1; j<sizeX; j++) {
            for (k=0; k<sizeProduct; k++) {
                product *= (long long) array[i+k][j-k];
            }
            if (product > maxProduct) {
                maxProduct = product;
                maxI = i;
                maxJ = j;
                searchType = 3;
            }
            product = 1;
        }
    }

    printf("max product of %d terms: %lld\n", sizeProduct, maxProduct);
    printf("maxX:%d, maxY:%d, searchType:", maxJ, maxI);
    switch (searchType) {
        case 0: printf("horizontal.\n"); break;
        case 1: printf("vertical.\n"); break;
        case 2: printf("diag1.\n"); break;
        case 3: printf("diag2.\n"); break;
        default: break;
    }

    return 0;
}