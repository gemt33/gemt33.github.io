#include <stdio.h>
#include <stdbool.h>

int abundant[6965];

bool isAbundant(int n) { // returns true if the sum of the proper divisors of n is greater than n
    int i;
    int sum = 0;

    for (i=1; i<=n/2; i++) {
        if (n%i == 0) {
            sum += i;
            if (sum > n) return true;
        }
    }
    return false;
}


int main() {
    int i, j, k;
    int counter = 0;
    int sum = 0;
    bool count;


    printf("%d, %d, %d\n", isAbundant(12), isAbundant(945), isAbundant(3));

    // init abundant array
    for (i=1; i<28124; i++) {
        if (isAbundant(i) == true) {
            abundant[counter] = i;
            counter++;
        }
    }

    for (i=1; i<28124; i++) {
        printf("%d, %d\n",i, sum);
        count = true;
        for (j=0; j<6965; j++) {
            if (abundant[j]+abundant[0] > i) break;
            for (k=0; k<6965; k++) {
                if (abundant[j]+abundant[k] > i) break;
                else if (abundant[j]+abundant[k] == i) {
                    count = false;
                    break;
                }
            }
        }
        if (count == true) sum += i;
    }


    printf("%d\n", sum);

    return 0;
}