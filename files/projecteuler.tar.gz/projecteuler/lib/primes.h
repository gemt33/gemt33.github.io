#include "primes.c"

bool isPrime(int n);
bool isPrime2(long long n, int *array);
int initPrimes(int array[], int size);