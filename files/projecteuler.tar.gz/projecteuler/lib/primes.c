#include <stdbool.h>
#include <math.h>

bool isPrime(int n) {
    int i;
    bool isPrime = true;

    if (n == 1) return false;

    for (i=2; i<=sqrt(n); i++) {
        if (n%i == 0) {
            isPrime = false;
            return isPrime;
        }
    }
    return isPrime;
}

bool isPrime2(long long n, int *array) {
    if (n<0) return false;
    int i;

    if (n == 1) return false;

    for (i=0; array[i]<=sqrt(n); i++) {
        if (n%array[i] == 0) {
            return false;
        }
    }
    return true;
}


int initPrimes(int *array, int size) {
    int index = 0;
    int i = 1;

    while (index<size) {
        if (isPrime(i) == true) {
            array[index] = i;
            index++;
        }
        i++;
    }
    return 0;
}