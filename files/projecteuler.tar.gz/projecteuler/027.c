#include <stdio.h>
#include "lib/primes.h" // to init the primes array and use isPrime2() function

// u(n) = n^2 + an + b
// b is prime because u(0) must be prime
// b is not negative because u(0) = b
// u(1) = 1 + a + b must be odd. Considering that b is odd, a is odd.

// there are 168 primes under 1k

int primes[1000]; // list of the 1st 1000 primes

int polynomial(int x, int a, int b) { // evaluate u(x)
    return x*x + x*a + b;
}

int main() {
    int a, b;
    int amax, bmax; // coefficients for longest prime series
    int u; // u(i)
    int i;
    int imax = 0;

    initPrimes(primes, 1000);


    for (b=0; b<168; b++) { // here b is the index in the primes array
        for (a=999; a > -1000; a -= 2) {
            i = 0;
            u = primes[b]; // u(0)
            while (isPrime2(u, primes) == true) {
                i++;
                u = polynomial(i, a, primes[b]);
            }
            if (i>imax) {
                amax = a;
                bmax = primes[b];
                imax = i;
            }
        }
    }

    printf("a=%d, b=%d, length=%d, a*b=%d\n", amax, bmax, imax, amax*bmax);
    return 0;
}