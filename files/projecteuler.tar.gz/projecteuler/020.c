#include <stdio.h>
#include <gmp.h> // arbitrary precision arithmetic library


// convert char between 0 and 9 to int
int charToInt(char c) {
    return c - 48;
}

int main() {
    char stringOfFact[1000]; // will contain 100!
    int sum = 0; // sum of the digits
    int index = 0;

    // initialisation of fact
    mpz_t fact;
    mpz_init(fact);
    mpz_set_ui(fact, 1);

    for (index=1; index<=100; index++) {
        mpz_mul_ui(fact, fact, index);
    }

    // convert fact to a string
    mpz_get_str(stringOfFact , 10, fact);

    // free memory
    mpz_clear(fact);

    index = 0;
    while (stringOfFact[index] != '\0') {
        sum += charToInt(stringOfFact[index]);
        index++;
    }

    // display result
    printf("%d\n", sum);

    return 0;
}