#include <stdio.h>
#include <gmp.h>

/*
215 = 32768 and the sum of its digits is 3 + 2 + 7 + 6 + 8 = 26.

What is the sum of the digits of the number 2**1000?
*/


int charToInt(char c) {
    return c - 48;
}


int main() {
    mpz_t hugeInteger;
    mpz_t one;
    int res = 0;
    int index = 0;

    // string that will contain the huge integer
    char stringOfInteger[2000];

    // init of hugeInteger
    mpz_init(hugeInteger);
    mpz_set_ui(hugeInteger, 0);
    mpz_init(one);
    mpz_set_ui(one, 1);

    // hugeInteger = 2**1000
    mpz_mul_2exp(hugeInteger, one, 1000);

    // convert hugeInteger to a string
    mpz_get_str(stringOfInteger, 10, hugeInteger);

    // add each char of the string to res
    while (stringOfInteger[index] != '\0') {
        res += charToInt(stringOfInteger[index]);
        index++;
    }


    printf("%d\n", res);

    return 0;
}