#include <stdio.h>
#include <stdbool.h>
#include <math.h>


int quick_pow10(int n) {
    static int pow10[10] = {1, 10, 100, 1000, 10000, 100000, 1000000};
    return pow10[n];
}


bool isPalindromic(int n) {
    int digits = (int) log10(n) + 1;
    int counter = digits;
    int arrayDigits[digits]; // we store all the digits of n as an array
    int i;
    bool isPalindromic;

    for (i=0; i<digits; i++) {
        counter--;
        arrayDigits[i] = (int) n/quick_pow10(counter); // we retrieve the most significant digit
        n = n - ((int) n/quick_pow10(counter)) * quick_pow10(counter); // we substract msd*10^x to remove the msd
    }

    for (i=0; i<(int)digits/2; i++) { // if digits is odd, we don't need to check the middle digit
        if (arrayDigits[i] != arrayDigits[digits-i-1]) { // if the symetrical digit is different
            isPalindromic = false;
            return isPalindromic;
        }
    }

    isPalindromic = true;
    return isPalindromic;
}



int main() {
    int i, j;
    int mul;
    int biggest = 0;

    for (i=999; i>99; i--) { // let's start with the biggest combination possible
        for (j=999; j>99; j--) { // since we want the biggest palindrome
            mul = i*j;
            if (isPalindromic(mul) == true) {
                if (mul > biggest) {
                    biggest = mul;
                }
            }
        }
    }
    printf("%d\n", biggest);

    return 0;
}




