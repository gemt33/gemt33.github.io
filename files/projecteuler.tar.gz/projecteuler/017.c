#include <stdio.h>
#include <stdbool.h>

/*
If the numbers 1 to 5 are written out in words: one, two, three, four, five, then there are 3 + 3 + 5 + 4 + 4 = 19 letters used in total.
If all the numbers from 1 to 1000 (one thousand) inclusive were written out in words, how many letters would be used?

NOTE: Do not count spaces or hyphens. For example, 342 (three hundred and forty-two) contains 23 letters and 115 (one hundred and fifteen) contains 20 letters. The use of "and" when writing out numbers is in compliance with British usage.
*/


// returns the number of letters an english written number has (from 1 to 1000)
int numberOfLetters(int n) {
    if (n < 1 || n > 1000) return 0;

    printf("%d: ", n);

    int letters = 0; // counter for the number of letters

    // special case for the "and" after x hundred if the 10s part is non zero
    bool andFlag = false;
    if (!(n%100 == 0 && (n/100)%10 != 0) && n > 99) {
        letters += 3;
        andFlag = true;
    }

    // special case between 10 and 19, we create a flag
    bool xteenFlag;
    if (((n/10)%10) == 1) {
        xteenFlag = true;
    } else xteenFlag = false;

    // one thousand case
    if ((n/1000) == 1) {
        letters = 11;
        printf("one thousand");
        printf(", %d\n", letters);
        return letters;
    }

    switch ((n/100)%10) {
        case 1: letters += 10; printf("one hundred "); break; // one hundred
        case 2: letters += 10; printf("two hundred "); break; // two hundreds
        case 3: letters += 12; printf("three hundred "); break; // three hundreds
        case 4: letters += 11; printf("four hundred "); break; // four hundreds
        case 5: letters += 11; printf("five hundred "); break; // five hundreds
        case 6: letters += 10; printf("six hundred "); break; // six hundreds
        case 7: letters += 12; printf("seven hundred "); break; // seven hundreds
        case 8: letters += 12; printf("eight hundred "); break; // eight hundreds
        case 9: letters += 11; printf("nine hundred "); break; // nine hundreds
        default : break;
    }

    if (andFlag == true) {
        printf("and ");
    }

        switch ((n/10)%10) {
        case 2: letters += 6; printf("twenty "); break; // twenty
        case 3: letters += 6; printf("thirty "); break; // thirty
        case 4: letters += 5; printf("forty "); break; // forty
        case 5: letters += 5; printf("fifty "); break; // fifty
        case 6: letters += 5; printf("sixty "); break; // sixty
        case 7: letters += 7; printf("seventy "); break; // seventy
        case 8: letters += 6; printf("eighty "); break; // eighty
        case 9: letters += 6; printf("ninety "); break; // ninety
        default : break;
    }

    if (xteenFlag == false) {
        switch (n%10) {
            case 1: letters += 3; printf("one"); break; // one
            case 2: letters += 3; printf("two"); break; // two
            case 3: letters += 5; printf("three"); break; // three
            case 4: letters += 4; printf("four"); break; // four
            case 5: letters += 4; printf("five"); break; // five
            case 6: letters += 3; printf("six"); break; // six
            case 7: letters += 5; printf("seven"); break; // seven
            case 8: letters += 5; printf("eight"); break; // eight
            case 9: letters += 4; printf("nine"); break; // nine
            default : break;
        }
    } else {
        switch (n%100) {
            case 10: letters += 3; printf("ten"); break; // ten
            case 11: letters += 6; printf("eleven"); break; // eleven
            case 12: letters += 6; printf("twelve"); break; // twelve
            case 13: letters += 8; printf("thirteen"); break; // thirteen
            case 14: letters += 8; printf("fourteen"); break; // fourteen
            case 15: letters += 7; printf("fifteen"); break; // fifteen
            case 16: letters += 7; printf("sixteen"); break; // sixteen
            case 17: letters += 9; printf("seventeen"); break; // seventeen
            case 18: letters += 8; printf("eighteen"); break; // eighteen
            case 19: letters += 8; printf("nineteen"); break; // nineteen
            default : break;
        }
    }

    printf(", %d\n", letters);
    return letters;
}



int main() {
    int lettersCounter = 0;
    int i;

    for (i=1; i<=1000; i++) {
        lettersCounter += numberOfLetters(i);
    }

    printf("%d\n", lettersCounter);

    return 0;
}