#include <stdio.h>

int main() {

    int i;
    int res = 0;

    for (i=1; i<1000; i++) {
        if ( (i%3 == 0) || (i%5 == 0) ) {
            res += i;
        }
    }

    printf("The sum of all mutiples of 3 or 5 below 1000 is : %d. \n", res);

    return 0;
}