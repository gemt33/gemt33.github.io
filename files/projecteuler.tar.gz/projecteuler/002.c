#include <stdio.h>

int sumEvenFibBelow(int below) {
    int res = 0;
    int a = 1;
    int b = 1;
    int temp;

    while (a < below ){

        temp = a;
        a = a + b; // the sum of the 2 precceding terms
        b = temp;

        if (a%2 == 0) { // if a is even add it to res
            res += a;
        }
    }
    return res;
}


int main() {

    int max = 4000000;
    int sum = sumEvenFibBelow(max);

    printf("The sum of all even fibbonaci numbers below %d is %d.\n", max, sum);

    return 0;
}